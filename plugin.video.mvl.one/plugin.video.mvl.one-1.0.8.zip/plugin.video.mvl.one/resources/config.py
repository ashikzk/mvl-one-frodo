__author__ = 'ashik'

plugin_id = 'plugin.video.mvl.one'
skin_id = 'skin.mvl.one'
